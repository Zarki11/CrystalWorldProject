package com.example.crystalworld;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrystalWorldApplicationTests {

    @Test
    void contextLoads() {
    }

}
