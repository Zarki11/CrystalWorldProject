package com.example.crystalworld.config;

import com.example.crystalworld.repository.UserRepository;
import com.example.crystalworld.service.CrystalWorldUserDetailsService;
import org.springframework.boot.autoconfigure.security.servlet.PathRequest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.crypto.password.Pbkdf2PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfiguration {

    private final CrystalWorldUserDetailsService crystalWorldUserDetailsService;

    public SecurityConfiguration(CrystalWorldUserDetailsService crystalWorldUserDetailsService) {
        this.crystalWorldUserDetailsService = crystalWorldUserDetailsService;
    }

    public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {

        return httpSecurity.authorizeHttpRequests(
                authorizeHttpRequests -> authorizeHttpRequests
                        .requestMatchers(PathRequest.toStaticResources().atCommonLocations()).permitAll()
                        .requestMatchers("/", "/users/login", "/users/register", "/users/login-error").permitAll()
                        .anyRequest().authenticated()
        ).formLogin(formLogin ->
        {
            formLogin.loginPage("/users/login")
                    .usernameParameter("email")
                    .passwordParameter("password")
                    .successForwardUrl("/")
                    .failureForwardUrl("/users/login-error");
        }).logout(logout -> {
            logout
                    .logoutUrl("/users/logout")
                    .logoutSuccessUrl("/")
                    .invalidateHttpSession(true);
        }).build();
    }


    @Bean
    public PasswordEncoder passwordEncoder(){
        return  Pbkdf2PasswordEncoder.defaultsForSpringSecurity_v5_8();
    }
}
