package com.example.crystalworld.model.enums;

public enum RarityEnum {

    COMMON, RARE, EXTREMELY_RARE
}
