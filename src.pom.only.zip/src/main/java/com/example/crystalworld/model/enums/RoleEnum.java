package com.example.crystalworld.model.enums;

public enum RoleEnum {

    ADMIN, USER;
}
